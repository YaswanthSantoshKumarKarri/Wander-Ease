import React from 'react'

import './TripPlansGallery.css'
const TripPlansGallery = () => {
    
  return (
    <div className='MainTripPlansGallery'>
      <h1 className="HeadingTripPlansGallery">Best places in Karnataka</h1>
      <div className="innerTripPlansGallery">
        <div className="subInnerTripPlansGallery">
          <div className='plancolumn'>
            <img width='200px' height='400px' src="https://completewellbeing.com/wp-content/uploads/2014/04/discover-the-beauty-of-trekking.jpg" alt="" />
          </div>
          <div className='plancolumn'>
            <img width='150px' height='230px' src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQG1y1DLqayogay_c1hokNNGb2Fmwv5zRf_PiVfY7vr6ze2wHjLGyf6bUk8ThmDL5YBTU&usqp=CAU" alt="" />
            <img width='150px' height='160px' src="https://www.revv.co.in/blogs/wp-content/uploads/2020/01/Places-to-Visit-in-Bangalore.jpg" alt="" />
          </div>
          <div className='plancolumn'>
          <img width='200px' height='195px' src="https://mediaim.expedia.com/destination/9/34469b10ae5e91095fda2aa8c74ddccf.jpg" alt="" />
          <img width='200px' height='193px' src="https://nurserynisarga.in/wp-content/uploads/2021/09/replicate-prediction-toulo7vlbbbrhdjm7fraxn7jj4-1.webp" alt="" />
          </div>
          <div className='plancolumn'>
          <img width='130px' height='300px' src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6EP5PxPeJIZ2GBiq8MdGdWAqHRpU6ik1mcTXuJ8x-Tw&s" alt="" />
          <button>View <br/>More</button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TripPlansGallery;