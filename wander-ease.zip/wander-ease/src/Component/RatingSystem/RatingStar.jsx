import React from 'react';

import FullStarOne from '../../Assets/ProfilePageImages/FullStar.png'
import HalfStarOne from '../../Assets/ProfilePageImages/HalfStar.png'
import EmptyStarOne from '../../Assets/ProfilePageImages/EmptyStar.png'

const StarRating = ({ rating }) => {
  const renderStars = () => {
    const stars = [];
    var fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    if(fullStars>5){
        fullStars=5;
    }
    // Render full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<img style={{display:"flex",float:"left",justifyContent:"center"}} key={i} width={"27px"} src={FullStarOne} alt="Full Star" />);
    }

    // Render half star if needed
    if (hasHalfStar) {
      stars.push(<img width={"27px"} style={{display:"flex",float:"left"}} key="half" src={HalfStarOne} alt="Half Star" />);
    }
    // Render empty stars to fill up to 5 stars
    const remainingStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<img width={"27px"} style={{display:"flex",float:"left",position:"relative", top:"-1px"}} key={`empty${i}`} src={EmptyStarOne} alt="Empty Star" />);
    }
    return stars;
  };

  return <div style={{margin:"0 0 0 250px"}}>{renderStars()}<br/></div>;
};

export default StarRating;