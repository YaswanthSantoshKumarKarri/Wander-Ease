import React from 'react'
import './LocationDetails.css'
import TerragolaMap from '../../../Assets/Images/Terragona/terragonaLoc.jpg'

const LocationDetails = () => {

  const locValue={
    googleMapsLink:'https://www.google.com/maps/place/Tarragona,+Spain/@41.1258048,1.2385834,13z/data=!3m1!4b1!4m6!3m5!1s0x12a3fcdbd3ddf159:0x920569a71387a3b2!8m2!3d41.1188827!4d1.2444909!16zL20vMGc3eWQ?hl=en&entry=ttu'
  }

  return (
    <>
        <div className="LocationDetailsMainSection">
            <div className="TourLoc">
              <h1>Terragana: A Hidden Gem</h1>
              <p>Terragana, nestled amidst lush greenery and serene landscapes, is a quaint destination waiting to be explored. Tucked away from the hustle and bustle of urban life, Terragana offers visitors a retreat into tranquility.</p>
              <img width='715px' src={TerragolaMap} />
              <svg width='20px' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
              </svg>
              <h1>The Legend of Terragola</h1>
              <p>
                  Terragola, steeped in mystery and legend, is a land shrouded in the mists of time. According to local folklore, Terragola was once a flourishing kingdom ruled by benevolent monarchs who were said to possess magical powers.

                  <br/><br/><strong>Ancient Origins:</strong> <br/>The origins of Terragola are traced back to ancient times when the land was believed to be inhabited by mystical beings and creatures of myth. Legend has it that the kingdom was founded by a powerful sorcerer who crafted the very landscape with his spells.

                  <br/><br/><strong>Golden Era:</strong> <br/>During its golden era, Terragola prospered as a center of learning and magic. Scholars from distant lands flocked to its renowned academies, seeking knowledge of arcane arts and wisdom passed down through generations.

                  <br/><br/><strong>The Great Cataclysm:</strong> <br/>However, the prosperity of Terragola was not to last. A great cataclysm, shrouded in myth and legend, befell the kingdom, plunging it into darkness and chaos. Some say it was the wrath of ancient gods, while others believe it was the result of a powerful curse unleashed by a vengeful sorcerer.</p>
            </div>
        </div>
    </>
  )
}

export default LocationDetails