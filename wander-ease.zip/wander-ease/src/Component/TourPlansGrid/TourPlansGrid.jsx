import React,{useEffect, useState} from 'react' 
import { useNavigate } from 'react-router-dom';

import './TourPlansGrid.css'
import PlacesDataServices from '../../Services/PlacesDataServices'

const TourPlansGrid = (props) => {
    const GridName=props.GridName;

    const [FetchedPlacesDataByName, setFetchedPlacesDataByName] = useState([]);
  useEffect(() => {
    setTimeout(() => {
      PlacesDataServices.getAllPlacesDataByName(GridName).then(Response=>{
        setFetchedPlacesDataByName(Response.data);
      })
    }, 1000);
  });
  const Navigate = useNavigate();

  const handleButtonClick = (number) => {
    const stateName = GridName;
    Navigate(`/detailsPage/${stateName}/${number}`);
  };
  return (
    <>
        <div className="MainTourPlansGrid">
            <div className="HeaderTourPlansGrid">
                <h1>See Our Latest Trip Plans<br/> of {FetchedPlacesDataByName.placeName}</h1>
                <h5>Adjustments can be made based on personal preferences <br/>and interests.</h5>
            </div>
            <div className="TourGridSection">
                <div className="innerGridSection">
                    <div className="gridSectionDiv">
                        <div className="innergridSectionDiv">
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesOne} alt="" />
                            <h5>itinerary covering many places</h5>
                            <h3>7-day trip</h3>
                            <button>
                                <svg onClick={() => handleButtonClick(1007)} width='17px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                                  <path fillRule="evenodd" d="M16.72 7.72a.75.75 0 0 1 1.06 0l3.75 3.75a.75.75 0 0 1 0 1.06l-3.75 3.75a.75.75 0 1 1-1.06-1.06l2.47-2.47H3a.75.75 0 0 1 0-1.5h16.19l-2.47-2.47a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
                                </svg>
                            </button>
                        </div>
                    </div>
                    <div className="gridSectionDiv">
                        <div className="innergridSectionDiv">
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesTwo} alt="" />
                            <h5>covering some popular places</h5>
                            <h3>5 days trip</h3>
                            <button>
                                <svg width='17px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                                  <path fillRule="evenodd" d="M16.72 7.72a.75.75 0 0 1 1.06 0l3.75 3.75a.75.75 0 0 1 0 1.06l-3.75 3.75a.75.75 0 1 1-1.06-1.06l2.47-2.47H3a.75.75 0 0 1 0-1.5h16.19l-2.47-2.47a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
                                </svg>
                            </button><br/><br/>
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesThree} alt="" />
                        </div>
                    </div>
                    <div className="gridSectionDiv ThirdSection">
                        <div className="innergridSectionDiv">
                            <h5>popular and must-visit destinations</h5>
                            <h3>3 days trip</h3>
                            <button>
                                <svg width='17px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                                  <path fillRule="evenodd" d="M16.72 7.72a.75.75 0 0 1 1.06 0l3.75 3.75a.75.75 0 0 1 0 1.06l-3.75 3.75a.75.75 0 1 1-1.06-1.06l2.47-2.47H3a.75.75 0 0 1 0-1.5h16.19l-2.47-2.47a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
                                </svg>
                            </button>
                            <br/><br/>
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesFour} alt="" />
                            <p>{FetchedPlacesDataByName.onelineSentence}</p>
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesFive} alt="" />
                        </div>
                    </div>
                    <div className="gridSectionDiv">
                        <div className="innergridSectionDiv">
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesSix} alt="" />
                            <h5>glimpse of must watch places</h5>
                            <h3>1 days trip</h3>
                            <button>
                                <svg width='17px' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                                  <path fillRule="evenodd" d="M16.72 7.72a.75.75 0 0 1 1.06 0l3.75 3.75a.75.75 0 0 1 0 1.06l-3.75 3.75a.75.75 0 1 1-1.06-1.06l2.47-2.47H3a.75.75 0 0 1 0-1.5h16.19l-2.47-2.47a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
                                </svg>
                            </button>
                            <br/><br/>
                            <img width='200px' height='200px' src={FetchedPlacesDataByName.gridImagesSeven} alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>
  )
}

export default TourPlansGrid