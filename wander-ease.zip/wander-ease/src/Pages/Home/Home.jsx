import React, {useEffect} from 'react'

import SelfDrive from '../../Assets/HomePageImages/DriveOwnCar.jpg';
import RentYourOwnCar from '../../Assets/HomePageImages/RentYourOwnCar.jpg';
import UserImage from '../../Assets/HomePageImages/user.png';
import DriverImage from '../../Assets/HomePageImages/driver.png';
import AboutMeImage from '../../Assets/HomePageImages/aboutme.jpg';
import { NavLink } from 'react-router-dom';
import { useLocation } from 'react-router-dom';

import './Home.css';

const Home = () => {

    const { pathname } = useLocation();
    useEffect(() => {
      window.scrollTo(0, 0);
    }, [pathname]);

  return (
    <div>     
        <div className="HomeContainer">
            <div className="HomeMainContext">
            <div className="HomeIntro">
                <div className="welcome"> Welcome to<br/></div>
                <div className="Logo">WANDER-EASE<br/></div>
                <p className="quote">Safely Soaring, Joyfully Exploring</p>
            </div>
            <div className="Homeform">
                <form className="homeForm"action="">
                    <div className="pickUpLoc">
                        <input type="text" placeholder='Pickup LOC'/>
                    </div>
                    <div className="destination">
                        <input type="text" placeholder='Destination LOC'/>
                    </div>
                    <div className="Date">
                        <input type="date" placeholder='Desired date'/>
                    </div>
                    <div className="typeOfVehicle">
                        <input type="text" placeholder='Desired vehicle'/>
                    </div>
                    <div className="submitBTN">
                        <button >
                          <svg xmlns="http://www.w3.org/2000/svg" className="icon"  viewBox="0 0 448 512">
                            <path d="M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"/>
                          </svg>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        </div>
        <div className="allAchievements">
            <div className="heading"><h1>Global mobility ecosystem driving communities forward</h1></div>
            <div className="AchievementsColumns">
                <div className="Achievement1">
                    <svg style={{width:"120px"}} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M480 48c0-26.5-21.5-48-48-48H336c-26.5 0-48 21.5-48 48V96H224V24c0-13.3-10.7-24-24-24s-24 10.7-24 24V96H112V24c0-13.3-10.7-24-24-24S64 10.7 64 24V96H48C21.5 96 0 117.5 0 144v96V464c0 26.5 21.5 48 48 48H304h32 96H592c26.5 0 48-21.5 48-48V240c0-26.5-21.5-48-48-48H480V48zm96 320v32c0 8.8-7.2 16-16 16H528c-8.8 0-16-7.2-16-16V368c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16zM240 416H208c-8.8 0-16-7.2-16-16V368c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16v32c0 8.8-7.2 16-16 16zM128 400c0 8.8-7.2 16-16 16H80c-8.8 0-16-7.2-16-16V368c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16v32zM560 256c8.8 0 16 7.2 16 16v32c0 8.8-7.2 16-16 16H528c-8.8 0-16-7.2-16-16V272c0-8.8 7.2-16 16-16h32zM256 176v32c0 8.8-7.2 16-16 16H208c-8.8 0-16-7.2-16-16V176c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16zM112 160c8.8 0 16 7.2 16 16v32c0 8.8-7.2 16-16 16H80c-8.8 0-16-7.2-16-16V176c0-8.8 7.2-16 16-16h32zM256 304c0 8.8-7.2 16-16 16H208c-8.8 0-16-7.2-16-16V272c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16v32zM112 320H80c-8.8 0-16-7.2-16-16V272c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16v32c0 8.8-7.2 16-16 16zm304-48v32c0 8.8-7.2 16-16 16H368c-8.8 0-16-7.2-16-16V272c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16zM400 64c8.8 0 16 7.2 16 16v32c0 8.8-7.2 16-16 16H368c-8.8 0-16-7.2-16-16V80c0-8.8 7.2-16 16-16h32zm16 112v32c0 8.8-7.2 16-16 16H368c-8.8 0-16-7.2-16-16V176c0-8.8 7.2-16 16-16h32c8.8 0 16 7.2 16 16z"/></svg>
                    <div className="AchevementColHeading"><span>250+</span><br/>Cities covered</div>
                    <p className='AchevementColParagraph'>Across India, Australia, New Zealand and the UK</p>
                </div>
                <div className="Achievement2">
                    <svg style={{width:"100px"}} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M160 0c-17.7 0-32 14.3-32 32s14.3 32 32 32h50.7L9.4 265.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L256 109.3V160c0 17.7 14.3 32 32 32s32-14.3 32-32V32c0-17.7-14.3-32-32-32H160zM576 80a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM448 208a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM400 384a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm48 80a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm128 0a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM272 384a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm48 80a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM144 512a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM576 336a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm-48-80a48 48 0 1 0 0-96 48 48 0 1 0 0 96z"/></svg>
                    <div className="AchevementColHeading"><span>55 Cr+</span><br/>Yearly rides</div>
                    <p className='AchevementColParagraph'>Booked by our customers every year</p>
                </div>
                <div className="Achievement3">
                    <svg style={{width:"100px"}} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M256 32H181.2c-27.1 0-51.3 17.1-60.3 42.6L3.1 407.2C1.1 413 0 419.2 0 425.4C0 455.5 24.5 480 54.6 480H256V416c0-17.7 14.3-32 32-32s32 14.3 32 32v64H521.4c30.2 0 54.6-24.5 54.6-54.6c0-6.2-1.1-12.4-3.1-18.2L455.1 74.6C446 49.1 421.9 32 394.8 32H320V96c0 17.7-14.3 32-32 32s-32-14.3-32-32V32zm64 192v64c0 17.7-14.3 32-32 32s-32-14.3-32-32V224c0-17.7 14.3-32 32-32s32 14.3 32 32z"/></svg>
                    <div className="AchevementColHeading"><span>12 Cr+</span><br/>Kilometers on S1</div>
                    <p className='AchevementColParagraph'>Distance covered on Ola S1 scooters within a year of launch</p>
                </div>
            </div>
        </div>
        <div className="AllServicesProvided">
            <div className="SelfDriveService">
                <div className="ServicesProvidedleft">
                    <img className='ImgServicesProvidedleft' src={SelfDrive} alt="" width={450} height={500}/>
                </div>
                <div className="ServicesProvidedright">
                    <div className="ServicesProvidedHeading">
                        Drive when you want, make what you need
                    </div>
                    <div className="ServicesProvidedParagraph">
                        Make money on your schedule with deliveries or rides—or both. You can use your own car or choose a rental through Wander-Ease.
                    </div>
                    <div className="SignInOptions">
                        <button>Get Started</button>
                        <div className="alreadyHaveAcc">
                            Already have an account? <span>Sign in</span>
                        </div>
                        </div>
                </div>
            </div>
            <div className="RentYourCarService">
            <div className="ServicesProvidedright">
                    <div className="ServicesProvidedHeading">
                        Make money by renting out your car
                    </div>
                    <div className="ServicesProvidedParagraph">
                        Connect with thousands of drivers and earn more per week with Wander-Ease's free fleet management tools.                    </div>
                    <div className="SignInOptions">
                        <button>Get Started</button>
                        <div className="alreadyHaveAcc">
                            Already have an account? <span>Sign in</span>
                        </div>
                        </div>
                </div>
                <div className="ServicesProvidedleft">
                    <img src={RentYourOwnCar} alt="" width={450} height={500}/>
                </div>  
            </div>
        </div>
        <div className="LoginSection">
            <div className="LoginSectionInnerContainer">
                <h1 className='H1LoginSectionInnerContainer'>Choose your way</h1>
                <div className="LoginTypes">
                    <div className="Container bg1">
                        <img src={UserImage} alt="" width={"100px"}/>
                        <div className="ContainerInnerSide">
                            <h3 className='H3ContainerInnerSide'>Wander-Ease for Users</h3>
                            <button className='BtnContainerInnerSide'>Go</button>
                        </div>
                        <p>Book cabs, Rent your car and much more</p>
                    </div>
                    <div className="Container">
                        <img src={DriverImage} alt="" width={"100px"}/>
                        <div className="ContainerInnerSide">
                            <h3>Wander-Ease for Drivers</h3>
                            <button>Go</button>
                        </div>
                        <p>Register as a driver to take rides, see your earnings and incentives</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div className="about-me">
            <div className="about-me-text">
                <h2>About Us</h2>
                <p>I am a full-stack developer, weaving innovation into every line of code. Freshly joined but seasoned in talent, we've recently crafted an app that simplifies online Cab booking system, reflecting our commitment to seamless user experiences. Stay tuned as I have embark on a journey to bring more transformative projects to life!</p>
                <button><NavLink className='navLink' to="/AboutUsPage">Learn More</NavLink></button>
            </div>
            <img src={AboutMeImage} alt="me" />
        </div>
    </div>
  )
}

export default Home