import React,{useState} from 'react'
import FemaleD from '../../Assets/ProfilePageImages/FemaleProfile.png'
import MaleD from '../../Assets/ProfilePageImages/mp1.png'

import "./Profile.css"
import StarRating from '../../Component/RatingSystem/RatingStar';

const Profile = () => {
    
    const [UserformData,setUserformData]=useState(
      {
        userId:0,
        userName: '',
        userEmail: '',
        userPassword:'',
        confirmUserPassword:'',
        role:'',
        userMobileNumber:'',
        userGender:'',
        userAge:'',
        userAdharId:'',
        userPanId:'',
        userAddress:'',
        userStates:'',
        userDOJ:''
      }
    );

    function autoCallProfileData(){
      
    }
    autoCallProfileData();

    return (
    <div className='ProfileMainContainer'>
      <div className="BasicIntro">
        <div className="darkBG">
          <div className="BasicIntroLeft">
            <h1>Hello {UserformData.userName}</h1>
            <div className="NameLoc">
              <h5>{UserformData.role}</h5>
              <p>
                <svg xmlns="http://www.w3.org/2000/svg" width="10px" viewBox="0 0 384 512">
                  <path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/>
                </svg>
                {UserformData.userStates}
              </p>
            </div>
            {UserformData.role==="Driver" &&(
              <>
                <div className="RatingStars">
              <h6>RANKINGS</h6>
              <div className="RatingStarsIcons">
                <h2>{(UserformData.rating>5 ) ? 5 : UserformData.rating}</h2>
                <p><StarRating rating={UserformData.rating} /></p>
              </div>
            </div>
              </>
            )}
            
            <p>This is your profile page. You can see the progress you've made with your work</p>
            <button>Edit Profile</button>
          </div>
        </div>        
      </div>
      <div className="MainDetals">
        <div className="MainDetailsLeft">
        <h2 className='HeadingAcc'>My account</h2>
          <div className="PersonalData">
            <h3>Personal Details</h3>
            <div className="DataRow">
              <div className="one">
                <label htmlFor="UserName">Name : </label>
                <input type="text" name="UserName" value={UserformData.userName} disabled/>
              </div>
              <div className="one">
              <label htmlFor="UserGender">Gender : </label>
              <input type="text" name="UserGender" value={UserformData.userGender} disabled/>
              </div>
              </div>
            <div className="DataRow">
            <div className="one">
                <label htmlFor="role">Role : </label>
                <input type="text" name="role" value={UserformData.role} disabled/>
              </div>
            </div>

          </div>
          <div className="DetailsSeperator"></div>
          <div className="PersonalData">
            <h3>Contact Details</h3>
            <div className="DataRow">
              <div className="one">
                <label htmlFor="UserEmail">EmailId : </label>
                <input type="email" name="UserEmail" value={UserformData.userEmail} disabled/>
              </div>
              <div className="one">
              <label htmlFor="UserMobileNumber">Mobile Number : </label>
              <input type="number" name="UserMobileNumber" value={UserformData.userMobileNumber} disabled/>
              </div>
              </div>
            <div className="DataRow">
            
              <div className="one">
              <label htmlFor="UserAddress">Address : </label>
              <textarea name="UserAddress" value={UserformData.userAddress} disabled/>
              </div>
              <div className="one">
                <label htmlFor="UserStates">State : </label>
                <input type="text" name="UserStates" value={UserformData.userStates} disabled/>
              </div>
            </div>
          </div>
          <div className="DetailsSeperator"></div>
          <div className="PersonalData">
            <h3>ID Proofs</h3>
            <div className="DataRow">
              <div className="one">
                <label htmlFor="Nationality">Nationality : </label>
                <input type="text" name="Nationality" value="Indian" disabled/>
              </div>
              <div className="one">
              <label htmlFor="UserAdharId">AdharId : </label>
              <input type="text" name="UserAdharId" value={UserformData.userAdharId} disabled/>
              </div>
              </div>
            <div className="DataRow">
            <div className="one">
                <label htmlFor="UserPanId">PanId : </label><br/>
                <input type="text" name="UserPanId" value={UserformData.userPanId} disabled/>
              </div>
              <div className="one">
              <label htmlFor="DrivingLicenseNo">Driving License No : </label>
              <input type='text' name="DrivingLicenseNo" value={UserformData.drivingLicenseNo} disabled/>
              </div>
            </div>
          </div>
          {UserformData.role==="Driver" && (
            <>
              <div className="DetailsSeperator"></div>
              <div className="PersonalData">
                <h3>Vehicle Details</h3>
                <div className="DataRow">
                  <div className="one">
                    <label htmlFor="DrivingLicenseNo">Driving License No : </label>
                    <input type="text" name="DrivingLicenseNo" value={UserformData.drivingLicenseNo} disabled/>
                  </div>
                  <div className="one">
                  <label htmlFor="VehicleLicensePlateNo">Vehicle License Plate No : </label>
                  <input type="text" name="VehicleLicensePlateNo" value={UserformData.vehicleLicensePlateNo} disabled/>
                  </div>
                  </div>
                <div className="DataRow">
                <div className="one">
                    <label htmlFor="VehicleTypes">Vehicle Types : </label><br/>
                    <input type="text" name="VehicleTypes" value={UserformData.vehicleTypes} disabled/>
                  </div>
                  <div className="one">
                  <label htmlFor="ModelName">Model Name : </label>
                  <input type='text' name="ModelName" value={UserformData.modelName} disabled/>
                  </div>
                </div>
              </div>
              <div className="DetailsSeperator"></div>
          <div className="PersonalData">
            <h3>Bank Account Details</h3>
            <div className="DataRow">
              <div className="one">
                <label htmlFor="BankAccNo">Bank Account No : </label>
                <input type="text" name="BankAccNo" value={UserformData.bankAccNo} disabled/>
              </div>
              <div className="one">
              <label htmlFor="IFSCcode">IFSC code : </label>
              <input type="text" name="IFSCcode" value={UserformData.iFSCcode} disabled/>
              </div>
              </div>
            <div className="DataRow">
            <div className="one">
                <label htmlFor="bankName">Bank Name : </label><br/>
                <input type="text" name="bankName" value={UserformData.bankName} disabled/>
              </div>
              <div className="one">
              <label htmlFor="bankAccType">Bank Account Type : </label>
              <input type='text' name="bankAccType" value={UserformData.bankAccType} disabled/>
              </div>
            </div>
          </div>
            </> 
          )}
          
          
        </div>
        <div className="MainDetailsRight" style={{position:'relative',top:(UserformData.role!=="Driver")? '-3vh' : "-235px"}}>
          <div className="innerMainDetailsRight">

          <div className="upperSection">
            <svg width={"30px"} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M347.1 24.6c7.7-18.6 28-28.5 47.4-23.2l88 24C499.9 30.2 512 46 512 64c0 247.4-200.6 448-448 448c-18 0-33.8-12.1-38.6-29.5l-24-88c-5.3-19.4 4.6-39.7 23.2-47.4l96-40c16.3-6.8 35.2-2.1 46.3 11.6L207.3 368c70.4-33.3 127.4-90.3 160.7-160.7L318.7 167c-13.7-11.2-18.4-30-11.6-46.3l40-96z"/></svg>
            <img width={"170px"} height={"185px"}src={(UserformData.userGender==="Male") ? MaleD : FemaleD} alt="" />
            <svg width={"30px"} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M208 352c114.9 0 208-78.8 208-176S322.9 0 208 0S0 78.8 0 176c0 38.6 14.7 74.3 39.6 103.4c-3.5 9.4-8.7 17.7-14.2 24.7c-4.8 6.2-9.7 11-13.3 14.3c-1.8 1.6-3.3 2.9-4.3 3.7c-.5 .4-.9 .7-1.1 .8l-.2 .2 0 0 0 0C1 327.2-1.4 334.4 .8 340.9S9.1 352 16 352c21.8 0 43.8-5.6 62.1-12.5c9.2-3.5 17.8-7.4 25.3-11.4C134.1 343.3 169.8 352 208 352zM448 176c0 112.3-99.1 196.9-216.5 207C255.8 457.4 336.4 512 432 512c38.2 0 73.9-8.7 104.7-23.9c7.5 4 16 7.9 25.2 11.4c18.3 6.9 40.3 12.5 62.1 12.5c6.9 0 13.1-4.5 15.2-11.1c2.1-6.6-.2-13.8-5.8-17.9l0 0 0 0-.2-.2c-.2-.2-.6-.4-1.1-.8c-1-.8-2.5-2-4.3-3.7c-3.6-3.3-8.5-8.1-13.3-14.3c-5.5-7-10.7-15.4-14.2-24.7c24.9-29 39.6-64.7 39.6-103.4c0-92.8-84.9-168.9-192.6-175.5c.4 5.1 .6 10.3 .6 15.5z"/></svg>
          </div>
          <div className="MiddleSection">
            <div className="MiddleSectionDataRow">
              <div className="MiddleSectionone">
                <h2>{UserformData.totalNoOfRides}</h2>
                <h6>Total Rides</h6>
              </div>
              <div className="MiddleSectionone">
                <h2>{UserformData.totalKmTravelled}</h2>
                <h6>Total Distance Travelled</h6>
              </div>
              {UserformData.role="Driver" && (
                <>
                  <div className="MiddleSectionone">
                    <h2>{UserformData.rating}</h2>
                    <h6>Rating</h6>
                  </div>
                </>
              )}
            </div>
          </div>
          <div className="SemiLowerSection">
            <div className="InnerSemiLowerSection">
              <h2>{UserformData.userName},<span>{UserformData.userAge}</span></h2>
              <h4>{UserformData.userGender}</h4>
              <h4>{UserformData.userStates},India</h4>
              <h4>{UserformData.userEmail}</h4>
              <h4>{UserformData.userMobileNumber}</h4>
            </div>
          </div>
          <div className="Sectiondivider"></div>
          <div className="LowerSection">
            “You have to believe in yourself when no one else does.” —Serena Williams
          </div>
        </div>
      </div>
       </div>
    </div>
  )
}
export default Profile