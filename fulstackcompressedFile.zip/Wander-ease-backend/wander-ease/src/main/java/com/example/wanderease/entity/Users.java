package com.example.wanderease.entity;

public class Users {

}
