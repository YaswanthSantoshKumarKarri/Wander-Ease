import React from 'react'

const DigitalProofs = () => {
  return (
          <></>          
  );
}

export default DigitalProofs