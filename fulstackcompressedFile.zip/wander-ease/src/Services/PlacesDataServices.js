import axios from "axios";

const REVIEW_API_BASE_URL="http://localhost:8080/places/Data/API/";

class PlacesDataServices{
    // savePlacesData(placesData){
    //     return axios.post(REVIEW_API_BASE_URL, placesData);
    // }
    getAllPlacesData(){
        return axios.get(REVIEW_API_BASE_URL+"getAll/");
    }
    getAllPlacesDataByName(placeName){
        return axios.get(REVIEW_API_BASE_URL+"getByName/"+placeName);
    }
    getReviewsByTripId(id){
        return axios.get(REVIEW_API_BASE_URL+"/"+id);
    }
    // deleteReviewsById(id){
    //     return axios.delete(REVIEW_API_BASE_URL+"/"+id);
    // }
}
export default new PlacesDataServices();