import {React,useState,useEffect} from 'react'
import { useParams  } from 'react-router-dom';
import './LocationDetails.css'
import TerragolaMap from '../../../Assets/Images/Terragona/terragonaLoc.jpg'
import PlacesDataServices from '../../../Services/PlacesDataServices'

const LocationDetails = () => {

  const locValue={
    googleMapsLink:'https://www.google.com/maps/place/Tarragona,+Spain/@41.1258048,1.2385834,13z/data=!3m1!4b1!4m6!3m5!1s0x12a3fcdbd3ddf159:0x920569a71387a3b2!8m2!3d41.1188827!4d1.2444909!16zL20vMGc3eWQ?hl=en&entry=ttu'
  }
  const { stateName, number } = useParams();
  const [FetchedStateDetails, setFetchedStateDetails] = useState([]);
  useEffect(() => {
    setTimeout(() => {
      PlacesDataServices.getAllPlacesDataByName(stateName).then(Response=>{
          setFetchedStateDetails(Response.data)
      })
    }, 1000);
  });
  return (
    <>
        <div className="LocationDetailsMainSection">
            <div className="TourLoc">
              <h1>{FetchedStateDetails.placeName}: {FetchedStateDetails.placeNickName}</h1>
              <p>{FetchedStateDetails.onelineSentence}</p>
              <img width='715px' height="715px" src={FetchedStateDetails.StateLocImage} />
              <svg width='20px' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
              </svg>
              <h1>The Legend of {FetchedStateDetails.placeName}</h1>
              <p>
              {FetchedStateDetails.overviewDataOne}
                  <br/><br/><strong>Ancient Origins:</strong> <br/>{FetchedStateDetails.historyOne}

                  <br/><br/><strong>Golden Era:</strong> <br/>{FetchedStateDetails.historyTwo}

                  <br/><br/><strong>The Great Cataclysm:</strong> <br/>{FetchedStateDetails.historyThree}</p>
            </div>
        </div>
    </>
  )
}

export default LocationDetails