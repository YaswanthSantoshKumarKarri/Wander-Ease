import React, { useState } from 'react'
import './TourPlan.css'

const TourPlan = () => {
  const tourPlan = [
    {
      dayCount:1,
      dayAgenda:'Departure',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'8.30PM',
      dayTask:'Check-in to hotel or accommodation.',
      dayDinner:'Dinner at a local restaurant or at the hotel.',
      dayExploring:'Local places near hotel'
    },
    {
      dayCount:2,
      dayAgenda:'Visiting Amsterdam, Prague and Vienna',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'8.30AM',
      dayTask:'Guided tour of key landmarks or attractions.',
      dayBreakfast:'Breakfast at the hotel.',
      dayLunch:'Lunch at a local eatery, experiencing regional cuisine.',
      dayDinner:'Dinner featuring local specialties.'
    },
    {
      dayCount:3,
      dayAgenda:'Rest',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'8.30AM',
      dayTask:'Local spaw and enjoy hotel providing services',
      dayBreakfast:'Breakfast at the hotel.',
      dayLunch:'Lunch at a local eatery, experiencing regional cuisine.',
      dayDinner:'Dinner featuring local specialties.'
    },
    {
      dayCount:4,
      dayAgenda:'Historical Tour',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'8.30AM',
      dayTask:'visiting historical monuments and going back in time spacially',
      dayBreakfast:'Breakfast at the hotel.',
      dayLunch:'Lunch at a local eatery, experiencing regional cuisine.',
      dayDinner:'Dinner featuring local specialties.'
    },
    {
      dayCount:5,
      dayAgenda:'Return',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'9.30AM',
      dayTask:'check-out hotel or accomodation, reaching aiport',
      dayBreakfast:'Breakfast at the hotel.',
    },
    {
      dayCount:6,
      dayAgenda:'Return',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'9.30AM',
      dayTask:'check-out hotel or accomodation, reaching aiport',
      dayBreakfast:'Breakfast at the hotel.',
    },
    {
      dayCount:7,
      dayAgenda:'Return',
      dayDescription:'Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium',
      dayDepartureTime:'9.30AM',
      dayTask:'check-out hotel or accomodation, reaching aiport',
      dayBreakfast:'Breakfast at the hotel.',
    }
  ];
  const objectCount = Object.keys(tourPlan).length;
  return (
    <>
      <div className="TourPlanMainSection">
        <h1>Tour Plan</h1>
        <div className="plannedMap">
          {tourPlan.map(item => (
            <div key={item.dayAgenda}>
              <div className="plannedMapLeft">
                <div className="innerPlannedMap">
                <div className="dayCount">{item.dayCount}</div>
                {item.dayCount!==objectCount && (
                  <>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                    <div className='pattern1'></div>
                  </>
                )}
                  
                </div>
              </div>
              <div className="plannedMapRight">
                <h2 className='h2DayAagenda'>Day {item.dayCount} : {item.dayAgenda}</h2>
                <p>{item.dayDescription}</p>
                <div className="bullets">
                  <div className="tasks">
                    {item.dayDepartureTime && (
                      <div><div className='BulletPointers'></div> Departure Time: {item.dayDepartureTime}</div>
                    )}
                    {item.dayTask && (
                      <div><div className='BulletPointers'></div> {item.dayTask}</div>
                    )}
                  </div>
                  <div className="food">
                    {item.dayBreakfast && (
                      <div><div className='BulletPointers'></div> {item.dayBreakfast}</div>
                    )}
                    {item.dayLunch && (
                      <div><div className='BulletPointers'></div> {item.dayLunch}</div>
                    )}
                    {item.dayDinner && (
                      <div><div className='BulletPointers'></div> {item.dayDinner}</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          
        </div>
      </div>
    </>
  )
}

export default TourPlan