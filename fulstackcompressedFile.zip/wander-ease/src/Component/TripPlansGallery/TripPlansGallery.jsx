import {React,useState,useEffect} from 'react'
import { useParams  } from 'react-router-dom';

import './TripPlansGallery.css'
import PlacesDataServices from '../../Services/PlacesDataServices';
const TripPlansGallery = () => {
  const { stateName, number } = useParams();
  const [FetchedStateDetails, setFetchedStateDetails] = useState([]);
  useEffect(() => {
    setTimeout(() => {
      PlacesDataServices.getAllPlacesDataByName(stateName).then(Response=>{
          setFetchedStateDetails(Response.data)
      })
    }, 1000);
  });
  return (
    <div className='MainTripPlansGallery'>
      <h1 className="HeadingTripPlansGallery">Best places in Karnataka</h1>
      <div className="innerTripPlansGallery">
        <div className="subInnerTripPlansGallery">
          <div className='plancolumn'>
            <img width='200px' height='400px' src={FetchedStateDetails.galleryImagesOne} alt="" />
          </div>
          <div className='plancolumn'>
            <img width='150px' height='230px' src={FetchedStateDetails.galleryImagesTwo} alt="" />
            <img width='150px' height='160px' src={FetchedStateDetails.galleryImagesThree} alt="" />
          </div>
          <div className='plancolumn'>
          <img width='200px' height='195px' src={FetchedStateDetails.galleryImagesFour} alt="" />
          <img width='200px' height='193px' src={FetchedStateDetails.galleryImagesFive} alt="" />
          </div>
          <div className='plancolumn'>
          <img width='130px' height='300px' src={FetchedStateDetails.galleryImagesSix} alt="" />
          <button>View <br/>More</button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TripPlansGallery;