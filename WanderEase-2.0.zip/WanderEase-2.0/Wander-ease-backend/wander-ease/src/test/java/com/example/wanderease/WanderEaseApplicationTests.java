package com.example.wanderease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WanderEaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
