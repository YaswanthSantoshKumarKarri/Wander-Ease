package com.example.wanderease;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WanderEaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(WanderEaseApplication.class, args);
	}

}
