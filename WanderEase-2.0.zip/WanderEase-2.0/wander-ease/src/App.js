import './App.css';
import DetailsPage from './Component/DetailsPage/DetailsPage';
import NavBar from './Component/NavBar/NavBar';
import Home from "./Pages/Home/Home";
import Foot from "./Component/Footer/foot"
import Profile from "./Pages/ProfilePage/Profile"

import { Routes ,Route } from 'react-router-dom';
import AboutUsPage from './Component/AboutUsPage/AboutUsPage';
import TourPlacesPage from './Pages/TourPlacesPage/TourPlacesPage';

function App() {
  return (
    <div className="App">
      <NavBar/>
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/AboutUsPage' element={<AboutUsPage/> } />
        <Route path='/DetailsPage' element={<DetailsPage/>} />
        <Route path='/Profile' element={<Profile/>} />
        <Route path='/TourPlaces' element={<TourPlacesPage/> } />
      </Routes>
      <Foot />
    </div>
  );
}

export default App;
