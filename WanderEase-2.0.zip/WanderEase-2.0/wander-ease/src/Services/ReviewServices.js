import axios from "axios";

const REVIEW_API_BASE_URL="http://localhost:8080/reviews/api/";

class ReviewService{
    saveReview(ReviewData){
        return axios.post(REVIEW_API_BASE_URL, ReviewData);
    }
    getAllReviews(){
        return axios.get(REVIEW_API_BASE_URL);
    }
    getReviewById(id){
        return axios.get(REVIEW_API_BASE_URL+"/"+id);
    }
    getReviewsByTripId(id){
        return axios.get(REVIEW_API_BASE_URL+"/"+id);
    }
    deleteReviewsById(id){
        return axios.delete(REVIEW_API_BASE_URL+"/"+id);
    }
}
export default new ReviewService();