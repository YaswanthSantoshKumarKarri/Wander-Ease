import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import "./LogIn.css";
import UserAuthService from '../../../Services/UserAuthService';
import DriverAuthService from "../../../Services/DriverAuthService";
import AdminAuthService from "../../../Services/AdminAuthService";

const LogIn = () => {
  //--------------------------user data structure------------
  const [LoginData,setLoginData]=useState({
    userName:"",
    userPassword:"",
    role:""
  });
  //--------------------------assigning login data-----------
    const handleChange = (e) => {
    const { name, value } = e.target;
      setLoginData({ ...LoginData, [name]: value });
  };
  //-------------------------handling login submission-------
  var navigate=useNavigate();
  const handleLoginSubmission=(e)=>{
    e.preventDefault();
    ((LoginData.role==="User")?(UserAuthService):((LoginData.role==="Driver")? (DriverAuthService) : (AdminAuthService))).getAuth(LoginData).then((response)=>{
        var responseData=response.data;
        console.log(responseData);
        if(response.data!=null){
          localStorage.setItem('token', JSON.stringify(response.data));
          navigate("/Profile");
        }else{          
          navigate("/SignUp");
        }
    })
    .catch((error)=>{console.log(error);});
  }

  return (
    <div className='RoleContainer'>
        <div className="RoleContainerBox">
          <div className="RoleLeft">
            <div className="RoleLeftInner">
              <h1>Welcome to LogIn</h1>
              <p>Don't have an Account?</p>
              <button><Link className='Link' to="/SignUp">Sign Up</Link></button>
            </div>
          </div>
          <div className="RoleRight">
              <h2>SignIn Here</h2>
              <form action="">
                  <input type="text" onChange={handleChange} name='userName' placeholder='Enter User Name here' required/>
                  <input type="password" onChange={handleChange} name='userPassword' placeholder='Enter User Password here' required/>
                  <select name="role" onChange={handleChange}  required>
                    <option value="User">User</option>
                    <option value="Driver">Driver</option>
                    <option value="Admin">Admin</option>
                  </select>
                  <button onClick={handleLoginSubmission}>Sign In</button>
              </form>
          </div>
        </div>
    </div>
  )
}

export default LogIn;