import React,{useEffect,useState} from 'react'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";

import './CustomersCarousal.css'
import ReviewServices from '../../Services/ReviewServices';
import StarRating from '../RatingSystem/RatingStar';

const CustomersCarousal = () => {
  
  const [FetchedReviews, setFetchedReviews] = useState([]);
  useEffect(() => {
    setTimeout(() => {
      ReviewServices.getAllReviews().then(Response=>{
        setFetchedReviews(Response.data)
      })
    }, 1000);
  });

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  const slider = React.useRef(null);

  return (
    <div className='MainCustomersCarousal'>
      <h1>Hear From Our Customers</h1>
      <h4>Don't just take our word for it. Hear what our customers have to say about us</h4>
      <div className="InnerCustomersCarousal">
      <Slider ref={slider} className='Slider' {...settings}>
      {FetchedReviews.map((row, index) => (
        <div key={index}>
        <div className='innersliderDiv'>
          <h3>{row.userName}</h3>
          <h5><StarRating rating={row.rating}/>  </h5>
          <div className='image'><img width="100px" height='100px' src='https://media.istockphoto.com/id/1146517111/photo/taj-mahal-mausoleum-in-agra.jpg?s=612x612&w=0&k=20&c=vcIjhwUrNyjoKbGbAQ5sOcEzDUgOfCsm9ySmJ8gNeRk='/></div> 
          <p>{row.comment}</p>
        </div>
        </div>
      ))}
      
    </Slider>
    </div>
    </div>    
  );
}



export default CustomersCarousal