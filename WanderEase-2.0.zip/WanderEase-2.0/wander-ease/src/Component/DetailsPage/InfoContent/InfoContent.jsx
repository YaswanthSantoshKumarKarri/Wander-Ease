import React,{useState} from 'react'
import FunImage from '../../../Assets/Images/Terragona/158575682-tarragona-spain-september-23-2018-castells-performance-during-santa-tecla-s-festival-by-colla-jove.jpg'
import PortarragonaAeria from '../../../Assets/Images/Terragona/PORTTARRAGONA_AERIA.jpg'
import FoodImage from '../../../Assets/Images/Terragona/los-ingredientes-basicos-de-la-gastronomia-espanola.jpg'
import './InfoContent.css'

const InfoContent = () => {
    const detailsInfo=useState({
        destinationImage:'../../Assets/Images/Tarragona.jpg',
        Name:"Tarragona",
        pricePerPerson:"$1740",
        rating:3,
        description:"Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo.",
        preBooking:1,
        ageLimit:"13+",
        destination:"spain",
        Departure:	"Main Square, Old Town",
        DepartureTime:	"Approximately 8.30AM" , 	
        ReturnTime:	"Approximately 7.30PM",
        DressCode:	"Casual, comfortable and light",  	
        Included:	 "5 Star Accommodation, Airport Transfer, Breakfast , Personal Guide",  
        NotIncluded: "Gallery, Ticket Lunch"    
})
  return (
    <>
                        <div className="HeadingAndPrice">
                                    <h1>{detailsInfo[0].Name}</h1>
                                    <h4><span>{detailsInfo[0].pricePerPerson}</span> / per person</h4>
                                </div>
                                <div className="detailsRating">{detailsInfo[0].rating}</div>
                                <div className="detailsDescription">{detailsInfo[0].description}</div>
                                <div className="detailsBookingDateAndAge">
                                    <div className="preBookingDate">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" width='17px' style={{margin:'0 5px',position:'relative', top:'3px'}} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5m-9-6h.008v.008H12v-.008ZM12 15h.008v.008H12V15Zm0 2.25h.008v.008H12v-.008ZM9.75 15h.008v.008H9.75V15Zm0 2.25h.008v.008H9.75v-.008ZM7.5 15h.008v.008H7.5V15Zm0 2.25h.008v.008H7.5v-.008Zm6.75-4.5h.008v.008h-.008v-.008Zm0 2.25h.008v.008h-.008V15Zm0 2.25h.008v.008h-.008v-.008Zm2.25-4.5h.008v.008H16.5v-.008Zm0 2.25h.008v.008H16.5V15Z" />
                                        </svg>
                                        {detailsInfo[0].preBooking}</div>
                                    <div className="preBookingDate">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" width='17px' style={{margin:'0 5px',position:'relative', top:'3px'}} viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
                                          <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                                        </svg>
                                        {detailsInfo[0].ageLimit} Age
                                    </div>
                                </div>
                                <div className="detailsTable">
                                    <div className="detailsTableLeft">
                                        <ul>
                                            <li>Destination</li>
                                            <li>Departure</li>
                                            <li>Departure Time</li>
                                            <li>Return Time</li>
                                            <li>Dress Code</li>
                                            <li>Included</li>
                                            <li>Not Included</li>
                                        </ul>
                                    </div>
                                    <div className="detailsTableRight">
                                        <ul>
                                            <li>{detailsInfo[0].destination}</li>
                                            <li>{detailsInfo[0].Departure}</li>
                                            <li>{detailsInfo[0].DepartureTime}</li>
                                            <li>{detailsInfo[0].ReturnTime}</li>
                                            <li>{detailsInfo[0].DressCode}</li>
                                            <li>{detailsInfo[0].Included}</li>
                                            <li>{detailsInfo[0].NotIncluded}</li>
                                        </ul>
                                    </div>

                                </div>
                                <div className="galleryDetails">
                                    <div className="galleryHeading">From our gallery</div>
                                    <div className="galleryDescription">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean <br/>massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</div>
                                    <div className="galleryImages">
                                        <div className="funImage">
                                            <img width='220px' height='220px' src={FunImage} alt="" />
                                        </div>
                                        <div className="cityImage">
                                            <img width='220px' height='220px' src={PortarragonaAeria} alt="" />
                                        </div>
                                        <div className="foodImage">
                                            <img width='220px' height='220px' src={FoodImage} alt="" />
                                        </div>
                                    </div>
                                </div>
    </>
  )
}

export default InfoContent