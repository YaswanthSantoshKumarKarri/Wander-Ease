import React,{useEffect} from 'react'
import { useLocation } from 'react-router-dom';

import './AboutUsPage.css';
import AboutUsPic from '../../Assets/aboutUsImages/360_F_636360143_g6f0Pp843joz8EdUVsMnKVujyLS9vZ7f-removebg-preview.png'
import CustomersCarousal from '../CustomersCarousal/CustomersCarousal';

const AboutUsPage = () => {
    //Automatically scrolls to top whenever pathname changes
    const { pathname } = useLocation();
    useEffect(() => {
      window.scrollTo(0, 0);
    }, [pathname]);

  return (
    <>
        <div className="MainHeadingSection">
            <div className="mask"></div>
            <h1>About Us</h1>
        </div>
        <div className="AboutUsDetailsSection">
            <div className="leftAboutUsDetailsSection">
                <img width='350px' src={AboutUsPic} alt="" />
            </div>
            <div className="rightAboutUsDetailsSection">
                <h1>Our Story</h1>
                <p>
                    Welcome to Wander-Ease, where travel meets innovation! I'm Yaswanth Santosh Kumar Karri, the creative force behind this game-changing travel agency app. Driven by a love for both technology and exploration, I set out to revolutionize the way people experience the world.
                    <br/>
                    <br/>
                    Our app goes beyond mere bookings; it's a comprehensive travel companion tailored to enrich every journey. From personalized suggestions to real-time flight updates, we've crafted an experience focused on convenience, efficiency, and unforgettable adventures. Join us as we push the boundaries of travel tech, empowering adventurers worldwide to embark on their next escapade with confidence.
                </p>
                <h2>Yaswanth Santosh Kumar Karri</h2>
                <h4>Developer, Wander-Ease</h4>
            </div>
        </div>
        <div className="CustomerCarousal">
            <CustomersCarousal />
        </div>
    </>
  )
}

export default AboutUsPage